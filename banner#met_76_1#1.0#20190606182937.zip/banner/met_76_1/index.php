<?php defined('IN_MET') or exit('No permission'); ?>
<div class="$uicss swiper-slide" m-id='{$ui.mid}' m-type=’banner’>
	<div class="swiper-container J-banner">
		<div class="swiper-wrapper">
			<tag action='banner.list'>
				<div class="swiper-slide">
					<img src="{$v.img_path}" />
				</div>
			</tag>
		</div>
		<div class="swiper-pagination J-bn-pagination"></div>
        <div class="swiper-button-prev"></div>
        <div class="swiper-button-next"></div>
	</div>
</div>