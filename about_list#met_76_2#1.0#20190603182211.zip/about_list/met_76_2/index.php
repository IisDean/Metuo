<?php defined('IN_MET') or exit('No permission'); ?>
<div class="$uicss" m-id='{$ui.mid}'>
	<div class="container">
		<div class="content-wrap clearfix">
			<div class="left-wrap full-img">
				<img src="{$ui.left_img|thumb:427,520}" title="{$ui.title}" />
			</div>
			<div class="right-wrap">
				<div class="right-sub">
					<div class="block-title">
						<h2>{$ui.title}</h2>
						<p>{$ui.title_msg}</p>
					</div>
					<tag action="category" type="current" cid="$ui['id']" num="1">
						<div class="lanm-title">
							<h3>{$m.name}</h3>
							<p>{$m.description}</p>
						</div>
						<ul class="about-list <if value="$ui['column_xs'] eq 1">
			            blocks-100
			            <else/>
			            blocks-xs-{$ui.column_xs} 
			        	</if>
			         	blocks-md-{$ui.column_md} blocks-lg-{$ui.column_lg} blocks-xxl-{$ui.column_xxl}">
		        			<tag action="category" type="son" cid="$m['id']" num="$ui['num']">
		        				<li class="about-item">
		        					<a <if value="$ui['type']">href="{$m.url}" title="{$m.name}" {$m.urlnew}</if>>
			        					<div class="full-img about-img">
			        						<img src="{$m.columnimg|thumb:72,72}" title="{$m.name}" class="transition" />
			        					</div>
			        					<div class="about-content">
			        						<h4>{$m.name}</h4>
			        						<p>{$m.description}</p>
			        						<span class="about-line"></span>
			        					</div>
		        					</a>
		        				</li>
							</tag>
						</ul>
					</tag>
				</div>
			</div>
		</div>
	</div>
</div>