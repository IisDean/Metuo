<?php defined('IN_MET') or exit('No permission'); ?>
<header class="$uicss navbar" m-id='{$ui.mid}' m-type="head_nav">
	<if value="$data['name']">
		<h1 hidden>{$data.name}</h1>
	<else/>
		<h1 hidden>{$c.met_webname}</h1>
	</if>	
	<!--  导航区域  -->
	<div class="container">
		<nav class="head-nav clearfix">
			<a href="{$c.index_url}" title="{$c.met_webname}" class="float-left logo-wrap">
                <img src="{$c.met_logo}" alt="{$c.met_webname}" met-id="83" met-table="config" met-field="value" class="">
			</a>
			<!-- 导航列表 -->
			<ul class="nav-list clearfix J-nav-list">
				<li class="nav-item">
					<a href="{$c.index_url}" title="{$c.met_webname}" class="nav-link transition">网站首页</a>
				</li>
				<tag action="category" type="head" class='active'>
					<li class="nav-item {$m.class}">
						<a href="{$m.url}" title="{$m.name}" {$m.urlnew} class="nav-link transition">{$m.name}</a>
					</li>
				</tag>
			</ul>
			<!--  移动端菜单按钮  -->
			<div class="float-right menu-btn J-menu-btn"><span class="middle transition"></span></div>
		</nav>
	</div>	
</header>