<?php defined('IN_MET') or exit('No permission'); ?>
<div class="$uicss swiper-slide" m-id='{$ui.mid}' m-type=’banner’>
	<div class="container">
		<div class="top-wrap clearfix">
			<div class="title-block float-left">
				<div class="title-block-content ani-top">
					<if value="$ui['block_title_sub1']">
						<span class="title-sub-1">{$ui.block_title_sub1}</span>
					</if>
					<span class="title-sub-2 <if value="$ui['block_title_sub2']">top-line</if>">
						<if value="$ui['block_title_sub2']">
							{$ui.block_title_sub2}
						</if>
						<tag action="category" cid="$ui['left_id']" num="1">
							<a href="{$m.url}" {$m.urlnew} title="{$m.name}" class="top-btn middle text-center">
								<i class="fa fa-long-arrow-right"></i>
							</a>
						</tag>
					</span>
					<if value="$ui['block_title']">
						<h2 class="block-title">{$ui.block_title}</h2>
					</if>
				</div>
				<tag action="category" cid="$ui['id']">
					<if value="$m['_index'] lt 1">
						<tag action="list" cid="$m['id']" num="1" type="all">
							<a href="{$v.url}" title="{$v.title}" {$v.urlnew} class="article-wrap transition clearfix">
								<p class="category-title">{$m.name}&nbsp;&nbsp;{$v.updatetime}</p>
								<h3 class="news-title">{$v.title}</h3>
								<p class="news-msg">{$v.description}</p>
								<span class="float-right icon fa fa-long-arrow-right"></span>
							</a>
						</tag>
					</if>
				</tag>
			</div>
			<div class="top-content-img full-img float-right article-container">
				<tag action="category" type="son" cid="$ui['id']" num="2">
					<if value="$m['_index'] eq 1">
						<tag action="list" cid="$m['id']" num="1" type="all">
							<a href="{$v.url}" title="{$v.title}" {$v.urlnew} class="article-container">
								<div class="news-img full-img">
									<img src="{$v.imgurl|thumb:$ui['img_w'],$ui['img_h']}" title="{$v.title}" />
								</div>
								<div class="article-wrap middle transition clearfix">
									<p class="category-title">{$m.name}&nbsp;&nbsp;{$v.updatetime}</p>
									<h3 class="news-title">{$v.title}</h3>
									<p class="news-msg">{$v.description}</p>
									<span class="float-right icon fa fa-long-arrow-right"></span>
								</div>
							</a>
						</tag>
					</if>
				</tag>
			</div>
		</div>
		<div class="bottom-wrap">
			<div class="swiper-container J-content-news">
				<div class="swiper-wrapper">
					<tag action="category" type="son" cid="$ui['id']">
						<if value="$m['_index'] lt 4"> 
							<tag action="list" cid="$m['id']" type="all" num="1">
								<div class="swiper-slide">
									<a href="{$v.url}" title="{$v.title}" {$v.urlnew} class="article-container">
										<div class="news-img full-img">
											<img src="{$v.imgurl|thumb:$ui['img_w'],$ui['img_h']}" title="{$v.title}" />
										</div>
										<div class="article-wrap transition clearfix">
											<p class="category-title">{$m.name}&nbsp;&nbsp;{$v.updatetime}</p>
											<h3 class="news-title">{$v.title}</h3>
											<p class="news-msg">{$v.description}</p>
											<span class="float-right icon fa fa-long-arrow-right"></span>
										</div>
									</a>
								</div>
							</tag>
						</if>
					</tag>
				</div>
				<div class="swiper-pagination J-new-poga"></div>
			</div>
		</div>
	</div>
</div>