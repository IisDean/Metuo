<?php defined('IN_MET') or exit('No permission'); ?>
<?php $img=strstr($ui['nav_bg_img'],"upload"); ?>
<if value="$img">
	<div class="$uicss nav-bg" m-id='{$ui.mid}'>
<else/>
	<div class="$uicss" m-id='{$ui.mid}'>
</if>
	<?php $img2=strstr($ui['border_img'],"upload"); ?>
	<if value="$img2">
		<div class="container border-img">
	<else/>
		<div class="container border-color">
	</if>
		<ul class="nav-list">
			<?php $img3=strstr($ui['active_img'],"upload"); ?>
			<tag action='category' cid="$data[releclass1]" type='current'>
				<if value="$img3">
			 		<li class="nav-item active-bg <if value="$data['classnow'] eq $m['id']">active</if>">
			 	<else/>
			 		<li class="nav-item active-color <if value="$data['classnow'] eq $m['id']">active</if>">
			 	</if>
					<a href="{$m.url}" title="{$m.name}" {$m.urlnew} class="nav-item-link"><span>{$ui.select_all}</span></a>
				</li>
				<tag action='category' cid="$m[id]" type='son' class="active">
					<if value="$img3">
				 		<li class="nav-item active-bg <if value="$data['classnow'] eq $m['id']">active</if>">
				 	<else/>
				 		<li class="nav-item active-color <if value="$data['classnow'] eq $m['id']">active</if>">
				 	</if>
				 		<if value="$m['sub']">
			 				<a class="nav-item-link"><span>{$m.name}</span></a>
			 			<else/>
			 				<a href="{$m.url}" title="{$m.name}" {$m.urlnew} class="nav-item-link"><span>{$m.name}</span></a>
			 			</if>
			 		</li>

			 		<if value="$img3">
				 		<li class="nav-item active-bg <if value="$data['classnow'] eq $m['id']">active</if>">
				 	<else/>
				 		<li class="nav-item active-color <if value="$data['classnow'] eq $m['id']">active</if>">
				 	</if>
				 		<if value="$m['sub']">
			 				<a class="nav-item-link"><span>{$m.name}</span></a>
			 			<else/>
			 				<a href="{$m.url}" title="{$m.name}" {$m.urlnew} class="nav-item-link"><span>{$m.name}</span></a>
			 			</if>
			 		</li><if value="$img3">
				 		<li class="nav-item active-bg <if value="$data['classnow'] eq $m['id']">active</if>">
				 	<else/>
				 		<li class="nav-item active-color <if value="$data['classnow'] eq $m['id']">active</if>">
				 	</if>
				 		<if value="$m['sub']">
			 				<a class="nav-item-link"><span>{$m.name}</span></a>
			 			<else/>
			 				<a href="{$m.url}" title="{$m.name}" {$m.urlnew} class="nav-item-link"><span>{$m.name}</span></a>
			 			</if>
			 		</li><if value="$img3">
				 		<li class="nav-item active-bg <if value="$data['classnow'] eq $m['id']">active</if>">
				 	<else/>
				 		<li class="nav-item active-color <if value="$data['classnow'] eq $m['id']">active</if>">
				 	</if>
				 		<if value="$m['sub']">
			 				<a class="nav-item-link"><span>{$m.name}</span></a>
			 			<else/>
			 				<a href="{$m.url}" title="{$m.name}" {$m.urlnew} class="nav-item-link"><span>{$m.name}</span></a>
			 			</if>
			 		</li><if value="$img3">
				 		<li class="nav-item active-bg <if value="$data['classnow'] eq $m['id']">active</if>">
				 	<else/>
				 		<li class="nav-item active-color <if value="$data['classnow'] eq $m['id']">active</if>">
				 	</if>
				 		<if value="$m['sub']">
			 				<a class="nav-item-link"><span>{$m.name}</span></a>
			 			<else/>
			 				<a href="{$m.url}" title="{$m.name}" {$m.urlnew} class="nav-item-link"><span>{$m.name}</span></a>
			 			</if>
			 		</li><if value="$img3">
				 		<li class="nav-item active-bg <if value="$data['classnow'] eq $m['id']">active</if>">
				 	<else/>
				 		<li class="nav-item active-color <if value="$data['classnow'] eq $m['id']">active</if>">
				 	</if>
				 		<if value="$m['sub']">
			 				<a class="nav-item-link"><span>{$m.name}</span></a>
			 			<else/>
			 				<a href="{$m.url}" title="{$m.name}" {$m.urlnew} class="nav-item-link"><span>{$m.name}</span></a>
			 			</if>
			 		</li>

			 	</tag>
		 	</tag>
	 	</ul>
	</div>
 	<div class="select-container">
 		<ul class="select-list"></ul>
		<tag action='category' cid="$data[releclass1]" type='current'>
			<tag action='category' cid="$m[id]" type='son' class="active">
			 	<ul class="select-list">
			 		<if value="$m['sub']">
						<li class="">
							<a href="{$m.met_weburl}" title="{$m.name}" class="select-item <if value="$data['classnow'] eq $m['id']">active</if>">{$ui.select_all}</a>
						</li>
						<tag action='category' cid="$m[id]" type='son'>
							<li class="">
								<a href="{$m.met_weburl}" title="{$m.name}" class="select-item <if value="$data['classnow'] eq $m['id']">active</if>">{$m.name}</a>
							</li>
						</tag>
					</if>
				</ul>
			</tag>
		</tag>	
 	</div>
</div>	