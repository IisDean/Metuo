<?php defined('IN_MET') or exit('No permission'); ?>
<div class="$uicss swiper-slide" m-id='{$ui.mid}'>
	<div class="container">
		<div class="top-wrap">
			<if value="$ui['block_title_sub1']">
				<span class="title-sub-1">{$ui.block_title_sub1}</span>
			</if>
				<span class="title-sub-2 <if value="$ui['block_title_sub2']">top-line</if>">
					<if value="$ui['block_title_sub2']">
						{$ui.block_title_sub2}
					</if>
					<tag action="category" cid="$ui['left_id']" num="1">
						<a href="{$m.url}" {$m.urlnew} title="{$m.name}" class="top-btn middle text-center">
							<i class="fa fa-long-arrow-right"></i>
						</a>
					</tag>
				</span>
			</if>
			<if value="$ui['block_title']">
				<h2 class="block-title">{$ui.block_title}</h2>
			</if>
			<if value="$ui['top_right_text']"><div class="top-right">{$ui.top_right_text}</div></if>
		</div> 
		<div class="content-wrap clearfix">
			<div class="left-wrap">
				<div class="swiper-container J-content-sw">
				    <div class="swiper-wrapper">
				    	<tag action="list" cid="$ui['left_id']" num="$ui['left_num']">
					        <div class="swiper-slide">
					        	<a href="{$v.url}" title="{$v.title}" {$g.urlnew} class="full-img">
					        		<img src="{$v.imgurl|thumb:$ui['left_img_w'],$ui['left_img_h']}" title="{$v.title}" />
					        		<div class="black-box">
					        			<div class="black-wrap left-black">
					        				<p class="case-title">{$v.title}</p>
					        				<p class="case-content ani" swiper-animate-effect="fadeInLeft" swiper-animate-duration="0.5s" swiper-animate-delay="0.3s">{$v.description}</p>
					        			</div>
					        		</div>
					        	</a>
					        </div>
					    </tag>
				    </div>
				    <!-- 如果需要分页器 -->
				    <div class="swiper-pagination"></div>
				    <!-- 前进后退按钮 -->
				    <div class="swiper-button-prev swiper-button-white"></div>
    				<div class="swiper-button-next swiper-button-white"></div>
				</div>
			</div>
			<div class="right-wrap">
				<ul class="case-list">
		        	<tag action="category" type="son" cid="$ui[right_id]">
		        		<if value="$m['_index'] lt $ui['right_num']">
							<li class="case-item">
								<a href="{$m.url}" title="{$m.name}" {$m.urlnew} class="full-img case-link">
									<img src="{$m.columnimg|thumb:$ui['right_img_w'],$ui['right_img_h']}" title="{$m.name}" />
									<div class="black-box transition">
										<div class="text-center black-wrap right-black">
											<p class="case-title">{$m.name}</p>
										</div>
									</div>
									<div class="shade-box transition" met-imgmask>
										<div class="text-center shade-wrap middle">
											<p class="case-title">{$m.name}</p>
											<if value="$m['description']">
												<span class="case-title-sub">{$m.description}</span>
											</if>
										</div>
									</div>
								</a>
							</li>
						</if>
					</tag>
					<if value="$ui['btn_text']">
						<li>
						<a href="{$ui.btn_link}" class="more-btn"><span class="middle">{$ui.btn_text}</span></a>
						</li>
					</if>
				</ul>
			</div>
		</div>
		<if value="$ui['btn_text']">
			<div class="text-center"><a href="{$ui.btn_link}" class="look-btn"><span>{$ui.btn_text}</span></a></div>
		</if>
	</div>
</div>