/*!
 * M['weburl']      网站网址
 * M['lang']        网站语言
 * M['tem']         模板目录路径
 * M['classnow']    当前栏目ID
 * M['id']          当前页面ID
 * M['module']      当前页面所属模块
 * default_placeholder 开发者自定义默认图片延迟加载方式，'base64'：灰色背景；自定义背景图片路径；'blur'：图片高斯模糊；默认为'blur'
 * met_prevarrow,met_nextarrow slick插件翻页按钮自定义html
 * device_type       客户端判断（d：PC端，t：平板端，m：手机端）
 */
METUI_FUN['$uicss'] = {
    name:'$uicss',
    init: function() {
        var m = METUI['$uicss'];//此处对应的最外层的那个css类名
        m.find(".J-menu-btn").on("click", function(){
            var $this = $(this).toggleClass('active');
            m.find(".J-nav-list").slideToggle(200);
        });
    },
    openSelect: function(){
        var $m = METUI['$uicss'];
        $m.find(".select-btn").on("touchstart", function(){
            $(this).toggleClass('active').siblings('.select-list').slideToggle(200);
        });
    },
    openScroll: function(){
        var $m = METUI['$uicss'];
        var mySwiper;
        $("body").append('</div><ul class="pagination-list J-pagination"></ul></div></div>');
        if( $(".is-scroll").val() == '0' || $('.is-page').val() != '10001' || $("body").width() < 992 ){
            $(".J-wrapper").removeClass('swiper-wrapper');
            return false;
        }
        $(".scroll-container").css('padding-top', $m.height()+'px');
        $(".swiper-sub").addClass('swiper-animate');
        mySwiper = new Swiper('.J-scroll-con', {
            direction: 'vertical',
            speed: 800,
            autoHeight: true,
            mousewheelControl : true,
            pagination : '.J-pagination',
            paginationType : 'custom',
            paginationCustomRender: function (swiper, currect, total) {
                var $html = '';
                for (var i = 1; i <= total; i++) {
                  if (currect == i) {
                    $html += '<li class="pagination-item transition active"><span></span></li>';
                  }else{
                    $html += '<li class="pagination-item transition"><span></span></li>';
                  }
                }
                return $html;//返回所有的页码html
            }
        });
    },
    cutFont: function(){
        //切换简繁体
        METUI['$uicss'].find('.J-cut-font').on("click", function(){
            var $this = $(this);
            var text = $this.find('a').text();
            if( text == '简体' ){
                $("body").s2t();
                $this.find('a').text('繁体');
            }else if( text == '繁体' ) {
                $("body").t2s();
                $this.find('a').text('简体');
            }
        });
    },
    initAniamate: function(){
        var $m = METUI['$uicss'];
        if( $("body").width() > 992 )return false;
        // $m.find(".nav-list .nav-item").each(function(index, ev){
        //     $(ev).css('transition-delay:', index*0.2+"s");
        // });
    },

};
var x = new metui(METUI_FUN['$uicss']);