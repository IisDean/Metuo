<?php defined('IN_MET') or exit('No permission'); ?>
<header class="$uicss navbar" m-id='{$ui.mid}' m-type="head_nav">
	<if value="$data['name']">
		<h1 hidden>{$data.name}</h1>
	<else/>
		<h1 hidden>{$c.met_webname}</h1>
	</if>	
	<!--  导航区域  -->
	<div class="container">
		<nav class="head-nav clearfix">
			<a href="{$c.index_url}" title="{$c.met_webname}" class="float-left logo-wrap">
                <img src="{$c.met_logo}" alt="{$c.met_webname}" met-id="83" met-table="config" met-field="value" class="">
			</a>
			<!-- 导航列表 -->
			<ul class="nav-list clearfix J-nav-list">
				<li class="nav-item">
					<a href="{$c.index_url}" title="{$c.met_webname}" class="nav-link transition">网站首页</a>
				</li>
				<!-- 导航 -->
				<tag action="category" type="head" class='active'>
					<li class="nav-item {$m.class}">
						<a href="{$m.url}" title="{$m.name}" {$m.urlnew} class="nav-link transition">{$m.name}</a>
					</li>
				</tag>
				<if value="$ui['simplified'] eq 1">
					<!-- 切换简繁体 -->
					<li class="nav-item J-cut-font" m-id='lang' m-type='lang'>
						<a href="javascript:;" class="nav-link transition">简体</a>
					</li>
				</if>
				<if value="$sub gt 1">
                    <if value="$c['met_lang_mark'] && $ui[lang_ok]">
						<!-- 切换语言 -->
						<li class="nav-item" m-id='member' m-type='member'>
							<div class="login-box">
								<lang>
									<if value="$data['lang'] eq $v['mark']">
										<a href="javascript:;" class="user-msg dropdown-toggle select-btn">
											<if value="$ui['langlist_icon_ok']">
												<span class="flag-icon full-img">
													<img src="{$v.flag}" alt="{$v.name}"/>
												</span>
											</if>
											<span class="user-name">{$v.name}</span>
											<span class="arrow-icon middle"><i class="fa fa-angle-down transition"></i></span>
										</a>
									</if>
								</lang>
								<ul class="lang-select select-list">
									<lang>
										<li>
											<a href="{$v.met_weburl}" title='{$v.name}' class="select-item transition" <if value="$v['newwindows']">target="_blank"<else/>target="_self"</if>>
												<if value="$ui['langlist_icon_ok']">
													<span class="flag-icon full-img">
		                                            	<img src="{$v.flag}" alt="{$v.name}">
		                                            </span>
		                                        </if>
												<span>{$v.name}</span>
											</a>
										</li>
									</lang>
								</ul>
							</div>
						</li>
					</if>
				</if>
				<if value="$c[met_member_register] && $ui[member]">
				<!-- 用户注册登录 -->
					<!-- 是否登录 -->
					<if value="$user">
						<!-- 是否开启商城 -->
						<if value="$c['shopv2_open']">
							<!-- 有商城登录状态 -->
							<li class="nav-item" m-id='member' m-type='member'>
								<div class="login-box">
									<a href="javascript:;" class="user-msg dropdown-toggle select-btn">
										<span class="user-head full-img">
											<img src="{$user.head}" alt="{$user.username}"/>
										</span>
										<span class="user-name">{$user.username}</span>
										<span class="arrow-icon middle"><i class="fa fa-angle-down transition"></i></span>
									</a>
									<ul class="select-list">
										<li>
											<a href="{$url.shop_profile}" title='{$word.app_shop_personal}' class="select-item transition">
												<i class="icon wb-user" aria-hidden="true"></i>
												<span>{$word.app_shop_personal}</span>
											</a>
										</li>
										<li>
											<a href="{$url.shop_order}" title='{$word.app_shop_myorder}' class="select-item transition">
												<i class="icon wb-order" aria-hidden="true"></i>
												<span>{$word.app_shop_myorder}</span>
											</a>
										</li>
										<li>
											<a href="{$url.shop_favorite}" title='{$word.app_shop_myfavorite}' class="select-item transition">
												<i class="icon wb-heart" aria-hidden="true"></i>
												<span>{$word.app_shop_myfavorite}</span>
											</a>
										</li>
										<li>
											<a href="{$url.shop_discount}" title='{$word.app_shop_mydiscount}' class="select-item transition">
												<i class="icon wb-bookmark" aria-hidden="true"></i>
												<span>{$word.app_shop_mydiscount}</span>
											</a>
										</li>
										<li>
											<a href="{$url.shop_member_base}&nojump=1" title='{$word.app_shop_settings}' class="select-item transition">
												<i class="icon wb-settings" aria-hidden="true"></i>
												<span>{$word.app_shop_settings}</span>
											</a>
										</li>
										<li>
											<a href="{$url.shop_member_login_out}" title='{$word.app_shop_out}' class="select-item transition">
												<i class="icon wb-power" aria-hidden="true"></i>
												<span>{$word.app_shop_out}</span>
											</a>
										</li>
									</ul>
								</div>
							</li>
						<else/>
							<!-- 无商城登录状态 -->
							<li class="nav-item" m-id='member' m-type='member'>
								<div class="login-box">
									<a href="javascript:;" class="user-msg dropdown-toggle select-btn">
										<span class="user-head full-img">
											<img src="{$user.head}" alt="{$user.username}"/>
										</span>
										<span class="user-name">{$user.username}</span>
										<span class="arrow-icon middle"><i class="fa fa-angle-down transition"></i></span>
									</a>
									<ul class="select-list">
										<li>
											<a href="{$c.met_weburl}member/basic.php?lang={$_M[lang]}" title='{$word.memberIndex9}' class="select-item transition">
												<i class="icon wb-user" aria-hidden="true"></i>
												<span>{$word.memberIndex9}</span>
											</a>
										</li>
										<li>
											<a href="{$c.met_weburl}member/basic.php?lang={$_M[lang]}&a=dosafety" title='{$word.memberIndex9}' class="select-item transition">
												<i class="icon wb-lock" aria-hidden="true"></i>
												<span>{$word.accsafe}</span>
											</a>
										</li>
										<li>
											<a href="{$c.met_weburl}member/login.php?lang={$_M[lang]}&a=dologout" title='{$word.memberIndex10}' class="select-item transition">
												<i class="icon wb-lock" aria-hidden="true"></i>
												<span>{$word.memberIndex10}</span>
											</a>
										</li>
									</ul>
								</div>
							</li>
						</if>
					<else/>
						<!-- 未登录 -->
						<li class="nav-item" m-id='member' m-type='member'>
							<div class="login-box">
								<a href="{$c.met_weburl}member/login.php?lang={$_M[lang]}" 
								title="{$word.login}" class="login-btn transition">
								{$word.login}
								</a>
								<a href="{$c.met_weburl}member/register_include.php?lang={$_M[lang]}" 
									title="{$word.register}" class="signin-btn transition">
								{$word.register}
								</a>
							</div>
						</li>
					</if>
				</if>
			</ul>
			<!--  移动端菜单按钮  -->
			<div class="float-right menu-btn J-menu-btn"><span class="middle transition"></span></div>
		</nav>
	</div>	
</header>
<input type="hidden" class="is-scroll" value="{$ui.is_scroll}" />
<input type="hidden" class="is-page" value="{$data.classnow}" />
<if value="$ui['is_scroll'] && $data['classnow'] eq 10001">
	<div class="scroll-container">
		<div class="swiper-container swiper-sub J-scroll-con">
		    <div class="swiper-wrapper J-wrapper">
</if>